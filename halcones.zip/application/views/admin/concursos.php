<div class="container">
    <a href="<?= base_url('admin/concursos/agregarConcurso')?>" class="btn btn-primary btn-lg"><i class="fa fa-plus"> Agregar concurso</i></a>
</div>