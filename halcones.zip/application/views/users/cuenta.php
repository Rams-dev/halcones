<div class="container">
<?php var_dump($datos);?>
</div>