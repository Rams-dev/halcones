<!DOCTYPE html>
<html lang="es">
<head>

<link rel="shortcut icon" href="<?= base_url('assets/img/logo.jpg')?>" type="image/x-icon" />
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
  
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous"> 
<!-- <link rel="stylesheet" href="<?= base_url('assets/dropify/dist/css/dropify.css')?>"> -->

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tutorias utvco</title>

    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/bootstrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/alertifyjs/css/alertify.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/alertifyjs/css/themes/default.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/nav1.css">
  <link rel="stylesheet" type="text/css" href="<?= base_url()?>assets/css/css.css">
  <!-- <script src="<?= base_url('assets/dropify/dist/js/dropify.js')?>"></script> -->

	<!-- <script src="<?php echo base_url()?>assets/jquery-3.2.1.min.js"></script> -->
	<script src="<?php echo base_url()?>assets/bootstrap/js/bootstrap.js"></script>
	<script src="<?php echo base_url()?>assets/alertifyjs/alertify.js"></script>
  
</head>
<body>
    
