<!DOCTYPE html>
<html lang="es">
<head>

<link rel="shortcut icon" href="<?= base_url('assets/img/logo.jpg')?>" type="image/x-icon" />
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<!-- <link rel="stylesheet" href="<?= base_url('assets/dropify/dist/css/dropify.css')?>"> -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tutorias utvco</title>

    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/bootstrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/alertifyjs/css/alertify.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/alertifyjs/css/themes/default.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/nav1.css">
  <link rel="stylesheet" type="text/css" href="<?= base_url()?>assets/css/css.css">
  <!-- <script src="<?= base_url('assets/dropify/dist/js/dropify.js')?>"></script> -->
  <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>

	<script src="<?php echo base_url()?>assets/bootstrap/js/bootstrap.js"></script>
	<script src="<?php echo base_url()?>assets/alertifyjs/alertify.js"></script>
  
</head>
<body class="body">

